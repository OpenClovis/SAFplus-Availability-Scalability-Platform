/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.update.internal.scheduler;

import org.eclipse.osgi.util.NLS;

public final class UpdateSchedulerMessages extends NLS {

	private static final String BUNDLE_NAME = "org.eclipse.update.internal.scheduler.UpdateSchedulerResources";//$NON-NLS-1$

	private UpdateSchedulerMessages() {
		// Do not instantiate
	}

	public static String SchedulerStartup_day;
	public static String SchedulerStartup_Monday;
	public static String SchedulerStartup_Tuesday;
	public static String SchedulerStartup_Wednesday;
	public static String SchedulerStartup_Thursday;
	public static String SchedulerStartup_Friday;
	public static String SchedulerStartup_Saturday;
	public static String SchedulerStartup_Sunday;
	public static String SchedulerStartup_1AM;
	public static String SchedulerStartup_2AM;
	public static String SchedulerStartup_3AM;
	public static String SchedulerStartup_4AM;
	public static String SchedulerStartup_5AM;
	public static String SchedulerStartup_6AM;
	public static String SchedulerStartup_7AM;
	public static String SchedulerStartup_8AM;
	public static String SchedulerStartup_9AM;
	public static String SchedulerStartup_10AM;
	public static String SchedulerStartup_11AM;
	public static String SchedulerStartup_12PM;
	public static String SchedulerStartup_1PM;
	public static String SchedulerStartup_2PM;
	public static String SchedulerStartup_3PM;
	public static String SchedulerStartup_4PM;
	public static String SchedulerStartup_5PM;
	public static String SchedulerStartup_6PM;
	public static String SchedulerStartup_7PM;
	public static String SchedulerStartup_8PM;
	public static String SchedulerStartup_9PM;
	public static String SchedulerStartup_10PM;
	public static String SchedulerStartup_11PM;
	public static String SchedulerStartup_12AM;
	public static String AutomaticUpdatesJob_AutomaticUpdateSearch;
	public static String AutomaticUpdatesPreferencePage_findUpdates;
	public static String AutomaticUpdatesPreferencePage_UpdateSchedule;
	public static String AutomaticUpdatesPreferencePage_findOnStart;
	public static String AutomaticUpdatesPreferencePage_findOnSchedule;
	public static String AutomaticUpdatesPreferencePage_downloadOptions;
	public static String AutomaticUpdatesPreferencePage_searchAndNotify;
	public static String AutomaticUpdatesPreferencePage_downloadAndNotify;
	public static String AutomaticUpdatesJob_EclipseUpdates1;
	public static String AutomaticUpdatesJob_UpdatesAvailable;
	public static String AutomaticUpdatesJob_EclipseUpdates2;
	public static String AutomaticUpdatesPreferencePage_at;
	public static String AutomaticUpdatesJob_UpdatesDownloaded;
	public static String AutomaticUpdatesJob_Updates;

	static {
		NLS.initializeMessages(BUNDLE_NAME, UpdateSchedulerMessages.class);
	}
}