/**
 * <copyright>
 *
 * Copyright (c) 2003-2006 IBM Corporation and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   IBM - Initial API and implementation
 *
 * </copyright>
 *
 * $Id: InternalEDataObject.java,v 1.5 2006/12/29 18:24:20 marcelop Exp $
 */
package org.eclipse.emf.ecore.sdo;


import java.io.ObjectStreamException;

import org.eclipse.emf.ecore.InternalEObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Internal EData Object</b></em>'.
 * @extends InternalEObject
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.ecore.sdo.SDOPackage#getInternalEDataObject()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface InternalEDataObject extends EDataObject, InternalEObject
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model exceptions="org.eclipse.emf.ecore.sdo.EObjectStreamException"
   *        annotation="http://www.eclipse.org/emf/2002/GenModel body='return <%org.eclipse.emf.ecore.sdo.util.SDOUtil%>.writeReplace(this);'"
   * @generated
   */
  Object writeReplace()throws ObjectStreamException;

} // InternalEDataObject
