/**
 * <copyright>
 *
 * Copyright (c) 2003-2004 IBM Corporation and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   IBM - Initial API and implementation
 *
 * </copyright>
 *
 * $Id: EType.java,v 1.4 2007/06/12 15:06:34 emerks Exp $
 */
package org.eclipse.emf.ecore.sdo;

import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;

import commonj.sdo.Type;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EType</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.ecore.sdo.EType#getEClassifier <em>EClassifier</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.emf.ecore.sdo.SDOPackage#getEType()
 * @model superTypes="org.eclipse.emf.ecore.sdo.Type"
 * @generated
 */
public interface EType extends EObject, Type
{
  /**
   * Returns the value of the '<em><b>EClassifier</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>EClassifier</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>EClassifier</em>' reference.
   * @see #setEClassifier(EClassifier)
   * @see org.eclipse.emf.ecore.sdo.SDOPackage#getEType_EClassifier()
   * @model resolveProxies="false" required="true"
   * @generated
   */
  EClassifier getEClassifier();

  /**
   * Sets the value of the '{@link org.eclipse.emf.ecore.sdo.EType#getEClassifier <em>EClassifier</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>EClassifier</em>' reference.
   * @see #getEClassifier()
   * @generated
   */
  void setEClassifier(EClassifier value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  EProperty getEProperty(String propertyName);

} // EType
